

<!-- ↓↓↓ Это один блок товара на главной ↓↓↓ -->


<?php $show_featured = true; $show_excerpt = true; ?>



<div style="width:200px; height:400px; float:left; margin:0 20px 20px 0;">



        <?php if($show_featured)  goods_featured_image("full"); ?>
        <?php
		the_title('<a href="'.esc_url(get_permalink()).'" class="popup"><h1 class="entry-title">', '</h1></a>


				 <div 	
				 id="popback"
				 style="
				 position: fixed; 
				 width: 100%; 
				 overflow:hidden;
				 top:0px;
				 left:0;
				 z-index:100000000 !important; 
				 display:none;
				 background-color: rgba(0, 0, 0, 0.8);
				 ">

					 <div><a href="#"  onclick="jQuery(this).parent().parent().hide();" style="font-size:30px; color:#FFF; margin:20px 0 0 20px; position: fixed; ">Close</a></div>
					 <div id="pop"
					 style="
					 width:800px;
					 margin:40px auto;
					 ">
					 </div>

				 </div>

		');
        ?>


	   <!--div class="entry-meta"><?php gridz_posted_on('M j, Y', '', __('By ','gridz')); ?></div-->    
	   <!--div>
		   <?php gridz_posted_on('M j, Y'); ?><br>
		   <?php gridz_comments_link(); ?>
	   </div-->


</div>


<!-- ↑↑↑ Это один блок товара на главной ↑↑↑ -->

    
    
    
    



</article>