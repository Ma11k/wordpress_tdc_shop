

jQuery(document).ready(
	function($) {
	   $('.popup').click(function(e) {
		  var url = $(this).attr('href');
		  jQuery(this).next().show();
		  jQuery(this).next().children('div#pop').load(url);		  
		  e.preventDefault(); // stop the browser from following the link		  
    });
});










