<!-- Это страница ТОВАРА -->

    <?php if(have_posts()): ?>
        <?php while(have_posts()): the_post(); ?>
        
        
        
            <?php 
            
echo '<a class="popup2" style="color:white; font-size:40px;" href="';      
echo get_permalink(get_adjacent_post(false,'',false)); 
echo '"> ← </a>';            

echo '<a class="popup2" style="color:white; font-size:40px;" href="';      
echo get_permalink(get_adjacent_post(false,'',true)); 
echo '"> → </a>';            




  echo '<div style="background:white; padding:20px;"><div>';
            
//Тайтл
            
	echo $post->post_title;        
	// the_title();
 

echo '</div><div class="tdc_info" style="font-size:40px;">';  
	
	    
	    
echo '</div><div class="tdc_info" style="font-size:40px;">';  	    
	    next_post_link('%link', __('→', 'gridz'));



//Картинка!

	$tdc_pic = get_field('tdc_wear_pic');        
	echo '<img style="width:300px; height:200px;" src="';
	echo $tdc_pic;
	echo '">';

 
//Контент 
 
 
  echo '<div class="entry-content">';
  echo $post->post_content;
  echo '</div><div class="tdc_info" style="font-size:40px;">';  


  //echo the_field( 'tdc_wear_type', '','false' );



//Тип одежды  
			  $wear_type = get_field('tdc_wear_type');
			  $wear_type_en = array("shorts", "t-shirt", "sweatshirt", "accessory");
			  $wear_type_ru  = array("Шорты", "Футболка", "Свитшот", "Аксессуар");

			  echo str_replace($wear_type_en, $wear_type_ru, $wear_type);


echo '</div><div class="tdc_info" style="font-size:40px;">';  


//Пол 
			  $wear_gender = get_field('tdc_wear_gender');
			  $wear_gender_en = array("male", "fem", "unisex");
			  $wear_gender_ru  = array("Муж.", "Жен.", "Унисекс");

			  echo str_replace($wear_gender_en, $wear_gender_ru, $wear_gender);


echo '</div><div class="tdc_info" style="font-size:40px;">';  


//Статус 
			  $wear_color = the_field('tdc_wear_status');
//			  $wear_color_en = array("male ", "female ", "unisex ");
//			  $wear_color_ru  = array("Муж.", "Жен.", "Унисекс");
//			  echo str_replace($wear_color_en, $wear_color_ru, $wear_color);






echo '</div><div class="tdc_info" style="font-size:40px;">';  


//Цeна

			  $wear_price = get_field('tdc_wear_price');
				echo $wear_price;
echo ' ₽';  

echo '</div><div class="tdc_info" style="font-size:40px;">';  



  
  
  
  
  
  
  
  
  
  echo '</div>';    
  
  
  
  
//  the_content();
  echo '</div>';
  
  
echo '</div>';

            
//get_template_part('content', get_post_format()); 
            
            
            ?>
            
            
            
            <!-- Показывать ли комменты на странице товара -->
            <!--?php comments_template(); ?-->
            
            
            
            
        <?php endwhile; ?>        
    <?php else : ?>
        <?php get_template_part('content', 'none'); ?>
    <?php endif; ?>



<script>
jQuery(document).ready(
	function($) {
	   $('.popup2').click(function(event) {
		  event.preventDefault(); // stop the browser from following the link		  
		  var url2 = $(this).attr('href');
//		  $(this).parent().parent().css( "background-color", "red" );
		  $(this).parent().load(url2);		  

    });
});

</script>